import 'package:ajeet_assignment/view/userDetailed_View.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../res/shimmer/homeView_Shimmer.dart';
import '../viewModel/userView_model.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('User List'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kToolbarHeight),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: userProvider.filterUsers,
              decoration: InputDecoration(
                hintText: 'Search by name or email...',
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(Icons.search),
              ),
            ),
          ),
        ),
      ),
      body: userProvider.isLoading
          ? const ShimmerLoading()
          : userProvider.error.isNotEmpty
          ? Center(child: Text(userProvider.error))
          : RefreshIndicator(
        onRefresh: () async {
          await userProvider.fetchUsers();
        },
        child: ListView.builder(
          itemCount: userProvider.filteredUsers.length,
          itemBuilder: (context, index) {
            final user = userProvider.filteredUsers[index];
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue,
                child: Text(
                  user.name?.substring(0, 1).toUpperCase() ?? '',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              title: Text(user.name ?? ''),
              subtitle: Text(user.email ?? ''),
              onTap: () {
                // Navigate to the detail screen
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UserDetailView(user: user),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
