import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/user.dart';

class UserProvider with ChangeNotifier {
  List<User> _users = [];
  List<User> _filteredUsers = [];
  bool _isLoading = true;
  String _error = '';

  List<User> get users => _users;
  List<User> get filteredUsers => _filteredUsers;
  bool get isLoading => _isLoading;
  String get error => _error;

  Future<void> fetchUsers() async {
    try {
      final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/users'));

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        _users = data.map((user) => User.fromJson(user)).toList();
        _filteredUsers = _users;
        _isLoading = false;
      } else {
        _error = 'Failed to load data';
        _isLoading = false;
      }
    } catch (e) {
      _error = 'Failed to load data: $e';
      _isLoading = false;
    }
    notifyListeners();
  }

  void filterUsers(String query) {
    query = query.toLowerCase();
    _filteredUsers = _users.where((user) {
      return user.name!.toLowerCase().contains(query) || user.email!.toLowerCase().contains(query);
    }).toList();
    notifyListeners();
  }
}
