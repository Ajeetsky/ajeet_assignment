import 'package:flutter/material.dart';
import '../models/user.dart';
import '../res/shimmer/userDetatiledView_shimmer.dart';

class UserDetailView extends StatelessWidget {
  final User? user;
  final bool isLoading;

  const UserDetailView({super.key, this.user, this.isLoading = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(user?.name ?? 'User Details'),
      ),
      body: isLoading
          ? const UserDetailViewShimmer()
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // UI logic for displaying details (as shown above)
              ],
            ),
          ),
        ),
      ),
    );
  }
}
